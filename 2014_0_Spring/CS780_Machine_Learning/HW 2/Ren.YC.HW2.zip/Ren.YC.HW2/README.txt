README file:

I used Eclipse for Java EE developers as IDE.

For Compile and Run:
Place the data file into the project folder which contains the Java original code.
Change the run configurations, under Arguments tab, program arguments frame, write the file name of the data file.
then click run button.